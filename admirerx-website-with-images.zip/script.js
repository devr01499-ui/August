function openForm(service) {
  document.getElementById("serviceInput").value = service;
  document.getElementById("contact").scrollIntoView({ behavior: "smooth" });
}